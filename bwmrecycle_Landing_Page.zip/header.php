<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Bhangarwala Waste Management - Recycle</title>
    <meta name="robots" content="index, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/favicon.png">

    <!-- CSS
	============================================ -->

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/plugins/all.min.css">
    <link rel="stylesheet" href="assets/css/plugins/flaticon.css">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/aos.css">
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->
    <!-- <link rel="stylesheet" href="assets/css/vendor/plugins.min.css">
    <link rel="stylesheet" href="assets/css/style.min.css"> -->

</head>

<body>

    <div class="main-wrapper">


        <!-- Preloader start -->
        <div id="preloader">
            <div class="preloader">
                <span></span>
                <span></span>
            </div>
        </div>
        <!-- Preloader End -->

        <!-- Header Start  -->
        <div id="header" class="section header-section header-section-06">

            <!-- Header Top Start  -->
            <div class="header-top-section d-none d-lg-block">
                <div class="container">
                    <div class="header-top-wrapper">
                        <div class="header-top-info">
                            <ul>
                                <li><i class="fa fa-phone"></i> +91-9029129329</li>
                                <li><i class="fa fa-envelope"></i> info@bwmgroup.in</li>
                            </ul>
                        </div>
                        <div class="header-social">
                            <span class="label">Follow Us</span>
                            <ul>
                                <li><a href="https://www.facebook.com/bwmgroupin1" target="_blank"><i class="fab fa-facebook-square"></i></a></li>
                                <li><a href="https://twitter.com/bwmgroupin"><i class="fab fa-twitter"></i> </a></li>
                                <li><a href="https://www.instagram.com/bwmgroupin/"><i class="fab fa-instagram"></i> </a></li>
                                <li><a href="https://www.linkedin.com/company/bwmgroupin"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Header Top End  -->

            <div class="container">

                <!-- Header Wrap Start  -->
                <div class="header-wrap">

                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/Mainlogo.png" alt=""></a>
                    </div>

                    <div class="header-menu d-none d-lg-block">
                        <ul class="main-menu">
                            <li class="active-menu">
                                <a href="index.php">Home</a>
                            </li>
                            <li>
                                <a href="#AboutUS">Aboute Us</a>
                            </li>
                            <li><a href="#OurProcess">Our Process</a>
                            </li>
                            <li><a href="#certificate">Certificate</a>
                            </li>
                            <li><a href="#Contact">Contact</a></li>
                        </ul>
                    </div>

                    <!-- Header Meta Start -->
                    <div class="header-meta">
                        <!-- Header Toggle Start -->
                        <div class="header-toggle d-lg-none">
                            <button data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                        <!-- Header Toggle End -->
                    </div>
                    <!-- Header Meta End  -->

                </div>
                <!-- Header Wrap End  -->

            </div>
        </div>
        <!-- Header End -->

        <!-- Offcanvas Start-->
        <div class="offcanvas offcanvas-start" id="offcanvasExample">
            <div class="offcanvas-header">
                <!-- Offcanvas Logo Start -->
                <div class="offcanvas-logo">
                    <a href="index.html"><img src="assets/images/logo/Mainlogo.png" alt=""></a>
                </div>
                <!-- Offcanvas Logo End -->
                <button type="button" class="close-btn" data-bs-dismiss="offcanvas"><i class="flaticon-close"></i></button>
            </div>

            <!-- Offcanvas Body Start -->
            <div class="offcanvas-body">
                <div class="offcanvas-menu">
                    <ul class="main-menu">
                        <li class="active-menu">
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a href="about.html">Aboute Us</a>
                        </li>
                        <li><a href="#">Pages</a>
                        </li>
                        <li><a href="#">Blog</a>
                        </li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
            </div>
            <!-- Offcanvas Body End -->
        </div>
        <!-- Offcanvas End -->